import React from "react";
function Viewhouse(){
    return (
        <h1>This is the view house component</h1>
    )
}
export default Viewhouse;