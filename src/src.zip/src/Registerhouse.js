import React from "react"
function Registerhouse()
{
    return (
        <h1>This is the register house component</h1>
    )
}
export default Registerhouse;